# Changelog

All notable changes to this reproducibility package are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project adheres to semantic versioning.

---

## [1.0.0] — 2026-11-21

First public release. Contains the complete 53-run dataset, tooling, and figures underlying the manuscript under review.

### Added

- `code/` — training pipeline for all seven fusion variants (`full`, `no_gate`, `no_ada`, `no_stmn`, `concat`, `s2_only`, `s1_only`) with a single command-line entry point.
- `scripts/run_main_grid.sh` — the 42-run main grid (7 variants × 2 scales × seeds 42/123/456), idempotent and resumable.
- `scripts/run_extended_seeds.sh` — 11 additional runs used only as dispersion cross-checks (`full`@5K seeds 789/1024; `no_stmn`@5K seven extra seeds; `no_stmn`@320K seeds 789/1024).
- `tools/dump_gates_full.py` — Ada-MBA gate statistics computed over the **complete** 24,119-sample validation split for all eight `full` checkpoints.
- `tools/plot_figures.py` — regenerates all four figures at 400 dpi (PNG) and as vector PDF.
- `tools/audit_metrics.py` — recomputes every cell of the main results table from the raw CSVs and asserts consistency.
- `results/all53_metrics.csv` — per-run OA / AA / Kappa / macro-F1 for all 53 runs.
- `results/gate_full_val.csv` — per-checkpoint gate values (8 rows).
- `figures/` — `fig1_overall_accuracy`, `fig2_stmn_contribution`, `fig3_gate_values`, `fig4_rank_shift`, each as PNG (400 dpi) and PDF.

### Changed relative to the earlier internal evaluation

This release supersedes the numbers used in the first submitted version. Three substantive corrections were made:

1. **The 5K results are now three-seed means for all seven variants.** Previously five variants were reported from a single seed (42), which made 5K rankings indistinguishable from initialisation noise. All 53 runs were retrained from scratch under one code path.
2. **The gate statistics were re-measured on a single code path.** Earlier versions compared 5K gate values obtained from a different code revision with 320K values from the current one, and reported the 5K gates qualitatively as "collapsed". Measured with identical code on the full validation split, the 5K mean activation is 0.376 ± 0.166 — higher, not lower, than the 320K value of 0.164 ± 0.122. The "collapse at small scale, recovery at large scale" account is therefore withdrawn and replaced by a convergence-based interpretation.
3. **The dispersion of `full` at 5K is now reported explicitly.** One of the three 5K seeds converges to a collapsed solution (24.76% OA), giving a cross-seed standard deviation of 15.35 against 0.46 at 320K — a 33-fold contraction. This variance signature, rather than the mean difference alone, is the primary evidence for the scale-dependent behaviour of the STMN branch.

Consequently, several numbers in the manuscript differ from the first submission: the best 320K variant is now `full` (60.99 ± 0.46%) rather than `no_gate` (60.34 ± 0.74%), and the only statistically separable pair at 320K is `no_gate` versus `concat` (t = 7.79, df = 2).

### Fixed

- `Table II` previously listed a 1,000-sample validation and test split for the 5K experiments. In the code, `--n_train 5000` restricts **only the training set**; validation and test are always the full 24,119 / 24,188 splits. All reported 5K numbers were already computed on the full test set, so the table was corrected, not the results.
- Training-time estimates in the reproducibility checklist were replaced with measured values (≈4.6 GPU-hours at 320K, ≈2.5 at 5K) instead of the earlier per-epoch extrapolation.

### Known limitations

- The seed=42 collapse in `full`@5K and the seed=456 collapse in `s2_only`@5K are reproduced deterministically and are reported in the tables rather than excluded from the mean. A four-seed mean excluding the pre-specified outlier is given in the text where relevant.
- With n = 3 seeds at 320K, all paired tests have df = 2 and therefore low power. Effect sizes are reported alongside p-values and should be read as estimates rather than confirmations.

---

## [Unreleased]

Nothing yet. Planned: a finer scale sweep between 5K and 320K to locate the point at which dispersion collapses.
