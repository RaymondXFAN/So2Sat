# Deployment and Reproduction Guide

Complete, tested procedure for reproducing all 53 training runs, the gate statistics, and the four figures in this repository.

**Verified on:** Ubuntu 22.04, Python 3.12, PyTorch 2.x with CUDA 12.x, NVIDIA RTX 4090 D (24 GB).

---

## 0. What you need

| Item | Requirement |
|---|---|
| GPU | 16 GB VRAM minimum; 24 GB recommended (peak observed: ~7.5 GB) |
| Disk | ~30 GB for the HDF5 files + ~2 GB for outputs |
| Time | ~9 GPU-hours end to end |
| Python | 3.10 – 3.12 |

Total compute breaks down as:

| Stage | Runs | Time per run | Subtotal |
|---|---|---|---|
| Smoke test | 1 | 0.5 min | 1 min |
| Main grid, 5K | 21 | ~5 min | ~1.8 h |
| Main grid, 320K | 21 | ~12 min | ~4.2 h |
| Extended seeds | 11 | 5–12 min | ~1.5 h |
| Gate statistics | 8 checkpoints | ~40 s each | ~6 min |
| Figures | — | — | < 1 min |

---

## 1. Environment

### 1.1 Linux / cloud GPU (recommended)

```bash
git clone <this-repo> && cd so2sat-fusion-repro

python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

Expected output: a version string followed by `True`. If you see `False`, the CUDA build and the driver do not match — reinstall PyTorch for your driver rather than upgrading the driver blindly.

### 1.2 Windows, Anaconda Prompt

```bat
conda create -n so2sat python=3.10 -y
conda activate so2sat
pip install -r requirements.txt
cd /d D:\work\so2sat-fusion-repro
python -c "import torch; print(torch.cuda.is_available())"
```

### 1.3 Windows, plain CMD

CMD does not load conda automatically:

```bat
call C:\Users\<you>\anaconda3\Scripts\activate.bat
conda activate so2sat
cd /d D:\work\so2sat-fusion-repro
```

### 1.4 PyCharm

Use `File → Open…` (not `New Project`) and select the repository folder. Then `Settings → Project → Python Interpreter → Add Interpreter → Conda Environment` and pick the `so2sat` environment. Scripts can then be run with right-click → `Run`.

---

## 2. Paths

All paths are resolved from `code/config.py`:

```python
ROOT = Path(os.environ.get("SO2SAT_ROOT", "<repo>/"))
DATA = ROOT / "data"
RAW  = DATA / "raw"
OUT  = ROOT / "out"
```

To put data and outputs on another disk, export before running:

```bash
export SO2SAT_ROOT=/mnt/data/so2sat
```

Every command in this guide assumes `SO2SAT_ROOT` points at the repository root.

---

## 3. Data preparation

### 3.1 Obtain the imagery

Download So2Sat LCZ42 from the original distribution and place the three splits as:

```
data/raw/training.h5      352,366 patches
data/raw/validation.h5     24,119 patches
data/raw/testing.h5        24,188 patches
```

Each patch is 32×32 with 10 Sentinel-2 and 8 Sentinel-1 channels.

### 3.2 Compute normalisation statistics

```bash
python code/prepare_so2sat.py
```

This writes `data/stats.json` (per-channel mean and standard deviation). It takes about 10 minutes and does not duplicate the imagery.

### 3.3 Verify

```bash
ls -lh data/raw/*.h5 data/stats.json
```

All four files must exist. A missing `stats.json` is the most common cause of a `FileNotFoundError` at launch.

---

## 4. Staged execution

Run the stages in order. Every script is **idempotent**: a run whose `out/<name>/table2_main.csv` already exists is skipped, so an interrupted job can simply be restarted.

### Stage 0 — environment and data check (1 min)

```bash
python -c "import torch,h5py,sklearn; print('ok')"
ls -lh data/raw/*.h5 data/stats.json
nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv,noheader
ls -d out/*/ 2>/dev/null | wc -l
```

Record the run count; you will use it to track progress.

### Stage 1 — smoke test (1 min)

```bash
python code/train.py --mode no_gate --seed 7777 --n_train 5000 --epochs 2
ls out/no_gate_5k_seed7777/
rm -rf out/no_gate_5k_seed7777
```

A correct run produces four files: `table2_main.csv`, `table5_classwise.csv`, `confusion_matrix.csv`, `train_log.csv`. After only two epochs the OA will be around 25% — that is expected, not a failure.

Why bother: this costs 30 seconds and prevents discovering a configuration error ten hours into a batch.

### Stage 2 — main grid, 42 runs (~6 h)

```bash
nohup bash scripts/run_main_grid.sh > logs_main_grid.txt 2>&1 &
echo "started PID=$!"
```

Monitor without blocking the terminal:

```bash
tail -n 20 logs_main_grid.txt
find out -name table2_main.csv | wc -l     # should climb to 42
```

### Stage 3 — extended seeds, 11 runs (~1.5 h)

```bash
nohup bash scripts/run_extended_seeds.sh > logs_ext_seeds.txt 2>&1 &
```

Final count should be **53**.

### Stage 4 — gate statistics (~6 min)

```bash
python tools/dump_gates_full.py | tee logs_dump_gates.txt
```

This loads each `full` checkpoint and evaluates the Ada-MBA gates over the **complete** validation split (24,119 samples). Do not rely on the `gate_value.txt` written during training — that file is computed from a single mini-batch and is noisy.

Expected: eight lines of output and a file `gate_full_val.csv` with eight rows.

A `TypeError: bad operand type for unary ~: 'NoneType'` printed at interpreter shutdown comes from h5py finalisation and does not affect results.

### Stage 5 — figures (~1 min)

```bash
python tools/plot_figures.py
ls -lh figures/
```

Produces `fig1`–`fig4` as 400 dpi PNG plus vector PDF.

### Stage 6 — self-check

```bash
python tools/audit_metrics.py
```

Recomputes every table entry from `results/all53_metrics.csv` and reports any mismatch. A clean run prints `all checks passed`.

---

## 5. Where the results live

| Level | Path | Content |
|---|---|---|
| Per run | `out/<run>/table2_main.csv` | OA / AA / Kappa / macro-F1 |
| Per run, detail | `out/<run>/table5_classwise.csv`, `confusion_matrix.csv`, `train_log.csv` | per-class accuracy, confusion matrix, per-epoch curves including `mean_gate` |
| Aggregated | `results/all53_metrics.csv`, `results/gate_full_val.csv`, `figures/` | one row per run, gate statistics, figures |

Three quick commands:

```bash
find out -name table2_main.csv | wc -l          # expected 53
head -5 results/all53_metrics.csv               # aggregated table
grep -c FAIL logs_*.txt 2>/dev/null             # expected 0
```

---

## 6. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError` | environment not activated | `source .venv/bin/activate` or `conda activate so2sat` |
| `can't open file 'code/train.py'` | wrong working directory | run from the repository root |
| `FileNotFoundError: data/stats.json` | statistics not computed | `python code/prepare_so2sat.py` |
| `CUDA out of memory` | another process holds the GPU | check `nvidia-smi`, kill the stale PID |
| Run count not increasing | process died | inspect `logs_main_grid.txt`, then restart — completed runs are skipped |
| Numbers differ by more than ±0.1 | different torch/CUDA build or different h5 | compare `full_5k_seed1024` (must be 52.15); check file checksums |
| `column: command not found` | `column` is optional | use `cat all53_metrics.csv` instead |
| Ctrl-C leaves the GPU busy | child processes survive | `nvidia-smi` → `kill -9 <PID>` |

---

## 7. Expected outputs and validation

After a successful run you should be able to confirm:

| Quantity | Value |
|---|---|
| Training runs | 53 |
| `no_stmn_5k`, 10 seeds | 50.53 ± 1.51 |
| `no_stmn` @320K, 5 seeds | 59.85 ± 1.28 |
| `full` @320K, 3 seeds | 60.99 ± 0.46 |
| `full` @5K, all seeds | 42.48 ± 15.35 |
| `full` @5K, excluding seed 42 | 51.30 ± 0.85 |
| Mean gate, 5K (5 seeds) | 0.376 ± 0.166 |
| Mean gate, 320K (3 seeds) | 0.164 ± 0.122 |

A deviation within ±0.02 in the mean values is consistent with a different CUDA build; a deviation larger than ±0.1 indicates a different data file or a different training configuration.

---

## 8. Cost

On a rented RTX 4090 at roughly USD 0.30/hour, a complete reproduction costs about USD 3. Storage for outputs (excluding checkpoints) is under 50 MB.

Checkpoints (`best_model.pt`, ~20 MB each) are written by every run but are not required for any released table or figure. They can be deleted freely.
