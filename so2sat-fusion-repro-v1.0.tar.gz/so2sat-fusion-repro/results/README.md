# Results directory

Two aggregated tables. Both are generated directly from per-run outputs and are the numbers used in the manuscript.

---

## `all53_metrics.csv`

One row per training run. 53 rows.

| Column | Meaning |
|---|---|
| `run` | Directory name under `out/`, see naming rules below |
| `oa` | Overall accuracy on the full test split, % |
| `aa` | Macro-averaged per-class accuracy, % |
| `kappa` | Cohen's kappa × 100 |
| `f1` | Macro-averaged F1, % |

All four metrics are computed once, from the checkpoint with the best validation OA, on the **complete 24,188-sample test split**. The 5K and 320K runs are evaluated on identical test data; they differ only in the size of the training subset.

### Run naming rules

| Pattern | Meaning |
|---|---|
| `<mode>` | 320K scale, seed 42 |
| `<mode>_seed<S>` | 320K scale, seed `S` |
| `<mode>_5k` | 5K scale, seed 42 |
| `<mode>_5k_seed<S>` | 5K scale, seed `S` |

Modes: `full`, `no_gate`, `no_ada`, `no_stmn`, `concat`, `s2_only`, `s1_only`.

### Run inventory

| Variant | Runs | Seeds |
|---|---|---|
| `full` | 8 | 320K: 42/123/456 · 5K: 42/123/456/789/1024 |
| `no_stmn` | 15 | 320K: 42/123/456/789/1024 · 5K: 42/123/456/789/1024/2048/3000/4096/5555/9999 |
| `no_gate`, `concat`, `no_ada`, `s2_only`, `s1_only` | 6 each | 320K: 42/123/456 · 5K: 42/123/456 |

The main grid (42 runs) uses seeds 42/123/456 at both scales. The remaining 11 runs are dispersion cross-checks and are reported separately where relevant.

### Two collapsed runs

Two runs converge to a degenerate solution and are retained in the table rather than silently dropped:

| Run | OA | Note |
|---|---|---|
| `full_5k` (seed 42) | 24.76 | Pre-specified outlier; z = −31.3 relative to the four-seed mean. Excluding it, `full`@5K is 51.30 ± 0.85 |
| `s2_only_5k_seed456` | 28.02 | Same failure mode in a single-modality baseline; shows the collapse is not specific to the STMN branch |

Both are reproducible bit-for-bit, so re-running will produce the same values.

---

## `gate_full_val.csv`

One row per `full` checkpoint. 8 rows.

| Column | Meaning |
|---|---|
| `scale` | `5K` or `320K` |
| `run` | Directory name |
| `seed` | Random seed |
| `a_01` | Mean gate α for the S2–S1 branch pair |
| `a_02` | Mean gate α for the S2–STMN pair |
| `a_12` | Mean gate α for the S1–STMN pair |
| `mean` | Mean of the three pairwise gates |
| `n_samples` | Number of validation samples used (24,119) |
| `sd_01`, `sd_02`, `sd_12` | Standard deviation of the per-batch gate value across the validation set |

### Measurement protocol

The gate value written during training is computed from a **single mini-batch** and is therefore noisy. The values in this file are produced by `tools/dump_gates_full.py`, which:

1. loads each `best_model.pt`,
2. runs a forward pass over the **complete** validation split (24,119 patches),
3. averages the gate scalar of each branch pair over all samples.

Within-run standard deviations (`sd_*`) are 0.007–0.025, so the estimates are stable inside a run. The large spreads reported in the manuscript are **across seeds**, not within runs.

Interpretation range: α = 0 means the cross-attention output is ignored (original features only), α = 0.5 an equal blend, α = 1 means only the cross-attention output is used.

---

## Recomputation

```bash
python tools/audit_metrics.py
```

Rebuilds every entry of the main results table from `all53_metrics.csv` and compares it with the values reported in the manuscript, printing a pass/fail line per cell.
