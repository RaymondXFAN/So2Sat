#!/usr/bin/env bash
# Extended seed sets (11 runs), used only as dispersion cross-checks.
#   full   @5K   : seeds 789, 1024
#   no_stmn@5K   : seeds 789, 1024, 2048, 3000, 4096, 5555, 9999
#   no_stmn@320K : seeds 789, 1024
#
# Idempotent. Run after scripts/run_main_grid.sh.
#
# Usage:  nohup bash scripts/run_extended_seeds.sh > logs_ext_seeds.txt 2>&1 &

set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

PY="${PYTHON:-python}"
LOG="$ROOT/logs_ext_seeds.txt"
mkdir -p "$ROOT/out" "$ROOT/logs"
: > "$LOG"

run_one () {
    local mode="$1" seed="$2" ntrain="$3" epochs="$4" out="$5"
    if [ -f "$out/table2_main.csv" ]; then
        echo "[SKIP] $out" | tee -a "$LOG"
        return 0
    fi
    echo "[RUN ] $out  start $(date '+%F %T')" | tee -a "$LOG"
    local extra=""
    [ -n "$ntrain" ] && extra="--n_train $ntrain"
    if $PY -u code/train.py --mode "$mode" --seed "$seed" $extra --epochs "$epochs" \
            > "logs/$(basename "$out").log" 2>&1; then
        if [ -f "$out/table2_main.csv" ]; then
            local oa
            oa=$(grep '^oa' "$out/table2_main.csv" | cut -d',' -f2)
            echo "[ OK ] $out  OA=${oa}%" | tee -a "$LOG"
        else
            echo "[FAIL] $out  (no table2_main.csv)" | tee -a "$LOG"
        fi
    else
        echo "[FAIL] $out  see logs/$(basename "$out").log" | tee -a "$LOG"
    fi
}

echo "=========== extended seeds started $(date '+%F %T') ===========" | tee -a "$LOG"

for s in 789 1024; do
    run_one full "$s" 5000 50 "out/full_5k_seed${s}"
done

for s in 789 1024 2048 3000 4096 5555 9999; do
    run_one no_stmn "$s" 5000 50 "out/no_stmn_5k_seed${s}"
done

for s in 789 1024; do
    run_one no_stmn "$s" "" 30 "out/no_stmn_seed${s}"
done

echo "" | tee -a "$LOG"
n=$(find out -name table2_main.csv 2>/dev/null | wc -l)
echo "=========== finished $(date '+%F %T') — $n runs present (target 53) ===========" | tee -a "$LOG"
