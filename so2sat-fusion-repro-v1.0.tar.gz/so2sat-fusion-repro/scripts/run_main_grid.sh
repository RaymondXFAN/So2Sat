#!/usr/bin/env bash
# Main grid: 7 variants x 2 scales x 3 seeds (42 runs).
# Idempotent: a run whose table2_main.csv already exists is skipped.
#
# Usage:  bash scripts/run_main_grid.sh
#         nohup bash scripts/run_main_grid.sh > logs_main_grid.txt 2>&1 &

set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

PY="${PYTHON:-python}"
LOG="$ROOT/logs_main_grid.txt"
FAILED="$ROOT/failed_runs.txt"
mkdir -p "$ROOT/out" "$ROOT/logs"
: > "$FAILED"

MODES="no_gate full concat no_stmn no_ada s2_only s1_only"
SEEDS="42 123 456"

run_one () {
    local mode="$1" seed="$2" ntrain="$3" epochs="$4" out="$5"
    if [ -f "$out/table2_main.csv" ]; then
        echo "[SKIP] $out" | tee -a "$LOG"
        return 0
    fi
    echo "[RUN ] $out  start $(date '+%F %T')" | tee -a "$LOG"
    local extra=""
    [ -n "$ntrain" ] && extra="--n_train $ntrain"
    if $PY -u code/train.py --mode "$mode" --seed "$seed" $extra --epochs "$epochs" \
            > "logs/$(basename "$out").log" 2>&1; then
        if [ -f "$out/table2_main.csv" ]; then
            local oa
            oa=$(grep '^oa' "$out/table2_main.csv" | cut -d',' -f2)
            echo "[ OK ] $out  OA=${oa}%  end $(date '+%F %T')" | tee -a "$LOG"
        else
            echo "[FAIL] $out  (exit 0 but no table2_main.csv)" | tee -a "$LOG"
            echo "$out" >> "$FAILED"
        fi
    else
        echo "[FAIL] $out  see logs/$(basename "$out").log" | tee -a "$LOG"
        tail -n 8 "logs/$(basename "$out").log" | sed 's/^/       | /' >> "$LOG"
        echo "$out" >> "$FAILED"
    fi
}

echo "================ main grid started $(date '+%F %T') ================" | tee -a "$LOG"

for m in $MODES; do
    # 5K scale
    for s in $SEEDS; do
        if [ "$s" = "42" ]; then out="out/${m}_5k"; else out="out/${m}_5k_seed${s}"; fi
        run_one "$m" "$s" 5000 50 "$out"
    done
    # 320K scale
    for s in $SEEDS; do
        if [ "$s" = "42" ]; then out="out/${m}"; else out="out/${m}_seed${s}"; fi
        run_one "$m" "$s" "" 30 "$out"
    done
done

echo "" | tee -a "$LOG"
n=$(find out -name table2_main.csv 2>/dev/null | wc -l)
echo "================ finished $(date '+%F %T') — $n runs present ================" | tee -a "$LOG"
if [ -s "$FAILED" ]; then
    echo "FAILED runs:" | tee -a "$LOG"
    cat "$FAILED" | tee -a "$LOG"
else
    echo "No failures." | tee -a "$LOG"
fi
