#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Recompute every reported statistic from results/all53_metrics.csv and check
it against the values used in the manuscript.

Usage:
    python tools/audit_metrics.py
    python tools/audit_metrics.py --strict      # exit code 1 on any mismatch
"""
import argparse
import csv
import statistics as st
import sys
from math import sqrt
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
METRICS = ROOT / 'results' / 'all53_metrics.csv'
GATES = ROOT / 'results' / 'gate_full_val.csv'

VARIANTS = ['no_gate', 'full', 'concat', 'no_stmn', 'no_ada', 's2_only', 's1_only']
MAIN_SEEDS = {42, 123, 456}

# Expected three-seed means (OA) as reported in the manuscript
EXPECTED_OA = {
    ('no_gate', '5K'): 51.35, ('no_gate', '320K'): 60.34,
    ('full', '5K'): 42.48, ('full', '320K'): 60.99,
    ('concat', '5K'): 52.04, ('concat', '320K'): 59.28,
    ('no_stmn', '5K'): 50.56, ('no_stmn', '320K'): 59.28,
    ('no_ada', '5K'): 51.62, ('no_ada', '320K'): 59.22,
    ('s2_only', '5K'): 42.13, ('s2_only', '320K'): 60.65,
    ('s1_only', '5K'): 23.48, ('s1_only', '320K'): 35.19,
}

EXPECTED_GATE_MEAN = {'5K': 0.376, '320K': 0.164}
TOL = 0.02


def parse_run(name):
    base, rest = None, ''
    for v in sorted(VARIANTS, key=len, reverse=True):
        if name == v or name.startswith(v + '_'):
            base, rest = v, name[len(v):]
            break
    if base is None:
        return None
    scale = '5K' if '5k' in rest.split('_') else '320K'
    seed = 42
    for tok in rest.split('_'):
        if tok.startswith('seed') and tok[4:].isdigit():
            seed = int(tok[4:])
    return base, scale, seed


def paired(a, b):
    d = [x - y for x, y in zip(a, b)]
    return st.mean(d), st.stdev(d), st.mean(d) / (st.stdev(d) / sqrt(len(d)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--strict', action='store_true')
    args = ap.parse_args()

    rows = []
    for r in csv.DictReader(open(METRICS)):
        p = parse_run(r['run'])
        if p:
            rows.append(dict(v=p[0], scale=p[1], seed=p[2],
                             oa=float(r['oa']), aa=float(r['aa']),
                             kappa=float(r['kappa']), f1=float(r['f1'])))

    print(f'[info] loaded {len(rows)} runs from {METRICS.name}')
    if len(rows) != 53:
        print(f'[warn] expected 53 runs, found {len(rows)}')

    cell = {}
    for r in rows:
        if r['seed'] in MAIN_SEEDS:
            cell.setdefault((r['v'], r['scale']), []).append(r)

    failures = 0
    print()
    print('=' * 78)
    print(f'{"Variant":<10}{"Scale":<6}{"OA (recomputed)":>20}{"OA (reported)":>16}{"":>4}')
    print('-' * 78)
    for v in VARIANTS:
        for sc in ['5K', '320K']:
            xs = [r['oa'] for r in cell.get((v, sc), [])]
            if not xs:
                print(f'{v:<10}{sc:<6}{"missing":>20}')
                failures += 1
                continue
            mu, sd = st.mean(xs), st.stdev(xs)
            exp = EXPECTED_OA[(v, sc)]
            ok = abs(mu - exp) <= TOL
            failures += 0 if ok else 1
            mark = 'ok' if ok else 'MISMATCH'
            print(f'{v:<10}{sc:<6}{f"{mu:.2f} ± {sd:.2f}":>20}{f"{exp:.2f}":>16}   {mark}')

    # dispersion
    print()
    print('=' * 78)
    print('Dispersion (cross-seed std of OA)')
    print('-' * 78)
    for v in VARIANTS:
        a = [r['oa'] for r in cell.get((v, '5K'), [])]
        b = [r['oa'] for r in cell.get((v, '320K'), [])]
        if a and b:
            print(f'{v:<10} 5K σ={st.stdev(a):5.2f}   320K σ={st.stdev(b):5.2f}')

    # paired tests at 320K
    print()
    print('=' * 78)
    print('Paired t-tests at 320K (n = 3, df = 2, critical |t| = 4.303)')
    print('-' * 78)

    def vals(v):
        return [r['oa'] for r in cell.get((v, '320K'), [])]

    for a, b in [('full', 'no_stmn'), ('full', 'no_gate'), ('full', 'concat'),
                 ('full', 's2_only'), ('no_gate', 'concat')]:
        if len(vals(a)) == 3 and len(vals(b)) == 3:
            m, sd, t = paired(vals(a), vals(b))
            sig = 'significant' if abs(t) > 4.303 else 'not significant'
            print(f'{a:<10} vs {b:<10} Δ={m:+.2f} ± {sd:.2f}  t={t:5.2f}  {sig}')

    # gates
    if GATES.exists():
        print()
        print('=' * 78)
        print('Gate statistics')
        print('-' * 78)
        g = list(csv.DictReader(open(GATES)))
        for sc in ['5K', '320K']:
            xs = [float(r['mean']) for r in g if r['scale'] == sc]
            if xs:
                mu, sd = st.mean(xs), st.stdev(xs)
                exp = EXPECTED_GATE_MEAN[sc]
                ok = abs(mu - exp) <= TOL
                failures += 0 if ok else 1
                print(f'{sc:<5} mean α = {mu:.3f} ± {sd:.3f}   reported {exp:.3f}   '
                      f'{"ok" if ok else "MISMATCH"}')

    print()
    print('=' * 78)
    if failures:
        print(f'RESULT: {failures} mismatch(es)')
    else:
        print('RESULT: all checks passed')
    print('=' * 78)

    if args.strict and failures:
        sys.exit(1)


if __name__ == '__main__':
    main()
