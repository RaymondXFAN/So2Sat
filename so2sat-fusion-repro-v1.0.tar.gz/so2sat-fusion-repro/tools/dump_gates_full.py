#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compute Ada-MBA gate statistics over the complete validation split.

The gate value logged during training is derived from a single mini-batch and is
noisy. This script loads each `full` checkpoint, runs a forward pass over the
whole validation split, and averages the gate scalar of each branch pair over
all samples. It also reports the per-batch standard deviation, which measures
within-run stability.

Output: gate_full_val.csv in the repository root.

Usage:
    python tools/dump_gates_full.py
"""
import csv
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'code'))

from config import CFG, DATA, OUT, RAW          # noqa: E402
from datasets import make_loader                # noqa: E402
from train import build_model                   # noqa: E402

SCALES = ['5K', '320K']
RUNS = [
    ('5K', 'full_5k'), ('5K', 'full_5k_seed123'), ('5K', 'full_5k_seed456'),
    ('5K', 'full_5k_seed789'), ('5K', 'full_5k_seed1024'),
    ('320K', 'full'), ('320K', 'full_seed123'), ('320K', 'full_seed456'),
]


def main():
    device = CFG['device']
    print(f'[env] device     = {device}')
    print(f'[env] batch size = {CFG["batch_size"]}')

    va = make_loader(RAW / 'validation.h5', shuffle=False,
                     stats_path=DATA / 'stats.json')
    print(f'[env] val batches = {len(va)} | samples = {len(va.dataset)}')

    rows = []
    for scale, name in RUNS:
        ckpt = OUT / name / 'best_model.pt'
        if not ckpt.exists():
            print(f'[skip] {name}: no best_model.pt')
            continue
        model = build_model('full').to(device)
        model.load_state_dict(torch.load(ckpt, map_location=device, weights_only=True))
        model.eval()

        acc = {'0-1': 0.0, '0-2': 0.0, '1-2': 0.0}
        series = {'0-1': [], '0-2': [], '1-2': []}
        n = 0
        with torch.no_grad():
            for s2_b, s1_b, _, _ in va:
                s2 = s2_b.to(device)
                s1 = s1_b.to(device)
                feats = [model.norm_s2(model.enc_s2(s2)),
                         model.norm_s1(model.enc_s1(s1)),
                         model.norm_stmn(model.stmn(s2))]
                gs = model.fuse.gate_stats(feats)
                bs = s2.size(0)
                for k, v in gs.items():
                    acc[k] += v * bs
                    series[k].append(v)
                n += bs

        a = {k: acc[k] / n for k in acc}
        mean_gate = sum(a.values()) / 3
        print(f'{scale:>4} {name:<20} a01={a["0-1"]:.4f} a02={a["0-2"]:.4f} '
              f'a12={a["1-2"]:.4f} mean={mean_gate:.4f} | '
              f'batch-sd: {np.std(series["0-1"]):.3f}/'
              f'{np.std(series["0-2"]):.3f}/{np.std(series["1-2"]):.3f}  n={n}')

        rows.append(dict(
            scale=scale, run=name,
            seed=(name.split('seed')[-1] if 'seed' in name else 42),
            a_01=round(a['0-1'], 4), a_02=round(a['0-2'], 4),
            a_12=round(a['1-2'], 4), mean=round(mean_gate, 4), n_samples=n,
            sd_01=round(float(np.std(series['0-1'])), 4),
            sd_02=round(float(np.std(series['0-2'])), 4),
            sd_12=round(float(np.std(series['1-2'])), 4)))

    out = ROOT / 'gate_full_val.csv'
    with open(out, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f'\nWritten {out}  ({len(rows)} rows)')


if __name__ == '__main__':
    main()
