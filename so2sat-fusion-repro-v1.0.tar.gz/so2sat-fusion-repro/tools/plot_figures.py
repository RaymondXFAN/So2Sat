# -*- coding: utf-8 -*-
"""Release-quality figures: large canvas, 400 dpi PNG + vector PDF."""
import csv
import statistics as st
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path('/sandbox/workspace/so2sat_repro')
OUT = ROOT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
DATA = Path('/sandbox/workspace/so2sat_paper/data')

V = ['no_gate', 'full', 'concat', 'no_stmn', 'no_ada', 's2_only', 's1_only']
LAB = {'no_gate': r'no\_gate', 'full': 'full', 'concat': 'concat',
       'no_stmn': r'no\_stmn', 'no_ada': r'no\_ada',
       's2_only': 'S2 only', 's1_only': 'S1 only'}
C = {'no_gate': '#8C9BAB', 'full': '#A67F78', 'concat': '#8FA68E',
     'no_stmn': '#C9A66B', 'no_ada': '#9B8AA6', 's2_only': '#7FA3A8',
     's1_only': '#B98B8B'}
INK = '#1F1F1F'
GRID = '#DCDCDC'
DPI = 400
MAIN = {42, 123, 456}

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 11,
    'axes.labelsize': 12, 'xtick.labelsize': 10.5, 'ytick.labelsize': 10.5,
    'legend.fontsize': 10, 'axes.edgecolor': INK, 'axes.labelcolor': INK,
    'text.color': INK, 'xtick.color': INK, 'ytick.color': INK,
    'axes.linewidth': 0.8, 'savefig.dpi': DPI,
})


def parse(name):
    base, rest = None, ''
    for v in sorted(V, key=len, reverse=True):
        if name == v or name.startswith(v + '_'):
            base, rest = v, name[len(v):]
            break
    if base is None:
        return None
    return base, ('5K' if '5k' in rest.split('_') else '320K')


rows = list(csv.DictReader(open(DATA / 'all53_metrics.csv')))
cell = {}
for r in rows:
    p = parse(r['run'])
    if not p:
        continue
    seed = int(r['run'].split('seed')[-1]) if 'seed' in r['run'] else 42
    if seed in MAIN:
        cell.setdefault((p[0], p[1]), []).append(float(r['oa']))


def ms(v, s):
    xs = cell.get((v, s), [])
    return (st.mean(xs), st.stdev(xs)) if xs else (None, None)


def save(fig, stem):
    fig.savefig(OUT / f'{stem}.png', dpi=DPI, bbox_inches='tight')
    fig.savefig(OUT / f'{stem}.pdf', bbox_inches='tight')
    plt.close(fig)


# ── Fig 1: OA, two panels ──
fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))
for ax, sc in zip(axes, ['5K', '320K']):
    data = [(v, *ms(v, sc)) for v in V]
    data = [d for d in data if d[1] is not None]
    data.sort(key=lambda x: x[1])
    ys = np.arange(len(data))
    for y, (v, mu, sd) in zip(ys, data):
        ax.barh(y, mu, color=C[v], edgecolor=INK, linewidth=0.6,
                height=0.66, alpha=0.93)
        ax.errorbar(mu, y, xerr=sd, fmt='none', ecolor=INK,
                    elinewidth=1.1, capsize=3, capthick=0.9)
        ax.text(mu + max(sd, 0.6) + 0.7, y, f'{mu:.2f}', va='center', fontsize=9.5)
    ax.set_yticks(ys)
    ax.set_yticklabels([LAB[d[0]] for d in data])
    ax.set_xlabel('Overall accuracy (%)')
    ax.set_title(f'{sc} scale  (mean ± std, n = 3)', fontsize=11.5, pad=6)
    lo = min(d[1] - d[2] for d in data) - 5
    ax.set_xlim(max(0, lo), max(d[1] + d[2] for d in data) + 8)
    ax.grid(axis='x', color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
fig.tight_layout(w_pad=2.0)
save(fig, 'fig1_overall_accuracy')

# ── Fig 2: STMN contribution ──
fig, ax = plt.subplots(figsize=(7.2, 4.8))
scs = ['5K', '320K']
xs = np.arange(len(scs))
w = 0.34
for k, v in enumerate(['no_stmn', 'full']):
    mus, sds = zip(*[ms(v, sc) for sc in scs])
    ax.bar(xs + (k - 0.5) * w, mus, w, yerr=sds, capsize=4,
           color=C[v], edgecolor=INK, linewidth=0.6, alpha=0.93,
           label=v.replace('_', r'\_'),
           error_kw=dict(elinewidth=1.0, capthick=0.9))
    for x, m in zip(xs + (k - 0.5) * w, mus):
        ax.text(x, m + 1.5, f'{m:.2f}', ha='center', fontsize=9.5)
for i, sc in enumerate(scs):
    mf, _ = ms('full', sc)
    mn, _ = ms('no_stmn', sc)
    ax.annotate(f'Δ = {mf - mn:+.2f}', xy=(i, max(mf, mn) + 6.5),
                ha='center', fontsize=10.5, color=C['full'])
ax.set_xticks(xs)
ax.set_xticklabels(scs)
ax.set_ylabel('Overall accuracy (%)')
ax.set_ylim(0, 78)
ax.legend(frameon=False, ncol=2, loc='upper left')
ax.grid(axis='y', color=GRID, linewidth=0.7)
ax.set_axisbelow(True)
for sp in ('top', 'right'):
    ax.spines[sp].set_visible(False)
fig.tight_layout()
save(fig, 'fig2_stmn_contribution')

# ── Fig 3: gate values ──
g = list(csv.DictReader(open(DATA / 'gate_full_val_recovered.csv')))
fig, ax = plt.subplots(figsize=(7.2, 4.6))
pairs = [('a_01', 'S2–S1'), ('a_02', 'S2–STMN'), ('a_12', 'S1–STMN')]
xs = np.arange(len(pairs))
w = 0.36
for k, (sc, col) in enumerate([('5K', '#C9A66B'), ('320K', '#8C9BAB')]):
    mus, sds = [], []
    for key, _ in pairs:
        vals = [float(r[key]) for r in g if r['scale'] == sc]
        mus.append(st.mean(vals))
        sds.append(st.stdev(vals))
    ax.bar(xs + (k - 0.5) * w, mus, w, yerr=sds, capsize=4, color=col,
           edgecolor=INK, linewidth=0.6, alpha=0.93, label=sc,
           error_kw=dict(elinewidth=1.0, capthick=0.9))
    for x, m in zip(xs + (k - 0.5) * w, mus):
        ax.text(x, m + 0.015, f'{m:.3f}', ha='center', fontsize=9)
ax.set_xticks(xs)
ax.set_xticklabels([p[1] for p in pairs])
ax.set_ylabel('Ada-MBA gate weight α')
ax.set_ylim(0, 0.95)
ax.legend(frameon=False, ncol=2, loc='upper right')
ax.grid(axis='y', color=GRID, linewidth=0.7)
ax.set_axisbelow(True)
for sp in ('top', 'right'):
    ax.spines[sp].set_visible(False)
fig.tight_layout()
save(fig, 'fig3_gate_values')

# ── Fig 4: rank shift ──
fig, ax = plt.subplots(figsize=(8.2, 3.4))
m5 = {v: ms(v, '5K')[0] for v in V}
m32 = {v: ms(v, '320K')[0] for v in V}
r5 = {v: i + 1 for i, (v, _) in enumerate(sorted(m5.items(), key=lambda x: -x[1]))}
r32 = {v: i + 1 for i, (v, _) in enumerate(sorted(m32.items(), key=lambda x: -x[1]))}
for v in V:
    ax.plot([0, 1], [r5[v], r32[v]], marker='o', markersize=7,
            color=C[v], linewidth=2.2, label=v.replace('_', r'\_'))
    ax.text(-0.06, r5[v], LAB[v], ha='right', va='center', fontsize=10, color=C[v])
    ax.text(1.06, r32[v], LAB[v], ha='left', va='center', fontsize=10, color=C[v])
ax.set_xlim(-0.45, 1.45)
ax.set_ylim(7.6, 0.4)
ax.set_xticks([0, 1])
ax.set_xticklabels(['5K scale', '320K scale'])
ax.set_yticks(range(1, 8))
ax.set_ylabel('rank (by OA)')
ax.tick_params(axis='x', length=0)
ax.grid(axis='y', color=GRID, linewidth=0.7)
ax.set_axisbelow(True)
for sp in ('top', 'right'):
    ax.spines[sp].set_visible(False)
fig.tight_layout()
save(fig, 'fig4_rank_shift')

print('figures written to', OUT)
for f in sorted(OUT.iterdir()):
    print(f'  {f.name}  {f.stat().st_size // 1024} KB')
